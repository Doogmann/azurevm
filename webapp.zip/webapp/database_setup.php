<?php
// Read DB settings provisioned at /etc/webapp/mysql.env
$env = @parse_ini_file('/etc/webapp/mysql.env', false, INI_SCANNER_TYPED) ?: [];

$host = $env['MYSQL_HOST'] ?? '127.0.0.1';
$db   = $env['MYSQL_DB']   ?? 'flexibleserverdb';
$user = $env['MYSQL_USER'] ?? 'mysqladmin';
$pass = $env['MYSQL_PASS'] ?? '';
$ssl  = strtoupper($env['MYSQL_SSL'] ?? 'REQUIRED'); // DISABLED|PREFERRED|REQUIRED|VERIFY_CA|VERIFY_IDENTITY

$charset = 'utf8mb4';
$dsn = "mysql:host={$host};dbname={$db};charset={$charset}";
$options = [
  PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  PDO::ATTR_EMULATE_PREPARES   => false,
];

if ($ssl !== 'DISABLED') {
  // Azure MySQL requires SSL unless configured otherwise
  $options[PDO::MYSQL_ATTR_SSL_CA] = '/etc/ssl/certs/ca-certificates.crt';
  // Skip strict verification to keep demo simple; tighten for prod.
  $options[PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT] = false;
}

try {
  $pdo = new PDO($dsn, $user, $pass, $options);
  $pdo->exec("
    CREATE TABLE IF NOT EXISTS contacts (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255) NOT NULL,
      message TEXT NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  ");
} catch (PDOException $e) {
  http_response_code(500);
  echo 'Database connection failed. Please check configuration. Error: ' . htmlspecialchars($e->getMessage());
  exit;
}
